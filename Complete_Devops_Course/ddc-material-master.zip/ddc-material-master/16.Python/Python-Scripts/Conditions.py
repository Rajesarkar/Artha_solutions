# IF Condition
"""
x = 21

if x < 30:
    print("Inside IF block")
    print("X is less than 30")

print("Rest of the code.")

x = 31

if x < 30:
    print("Inside IF block")
    print("X is less than 30")

print("Rest of the code.")


# If/Else Condition
x = 31

if x < 30:
    print("Inside of block")
    print("X is less than 30")
else:
    print("Inside else block")
    print("x is greater than 30")

"""
# If/Elif/Else Condition
x = 40

if x > 40:
    print("X is greater than 40")
elif x == 40:
    print("X is equal to 40")
else:
    print("X is less than 40")
