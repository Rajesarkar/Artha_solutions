# This is a single line comment

"""
This is a multi line comment.
Its is double quotes(thrice)
"""

'''
This is a multi line comment.
Its is single quotes(thrice)
'''

skill = "DevOps"
print("skill")
print('skill')
print(skill)

print("""
This is a paragraph string,
This is the second line of the paragraph,
third line
""")

print('''
This is a paragraph string,
This is the second line of the paragraph,
third line
''')

#print(this is a text)
print("this is a text")
