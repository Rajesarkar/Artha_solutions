#!/bin/bash

echo "The $SEASON season is more than expected, this time."
