#!/bin/bash

for FILENAME in $(ls)
do
  cat $FILENAME
done
